/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export', // Forces the project to compile down into a static website
  images: {
    unoptimized: true, // Prevents custom image tags from breaking on GitHub servers
  },
};

export default nextConfig;